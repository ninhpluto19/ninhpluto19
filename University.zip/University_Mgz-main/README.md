# University-Mgz
## Admin Account
admin@gmail.com


123123
## Marketing Manager Account
manager@gmail.com


123123
## Marketing Coordinator Account
1. computingcoordinator@gmail.com


   123123
3. businesscoordinator@gmail.com


   123123
5. graphiccoordinator@gmail.com


   123123
7. lawcoordinator@gmail.com


   123123
## Student Account
1. student1@gmail.com


   123123
3. student2@gmail.com


   123123
5. student3@gmail.com


   123123
7. student4@gmail.com


   123123
## How To Use
```bash
# Clone this repository
$ git clone https://github.com/mylovenkt/University_Mgz

# Go into the repository
$ cd University_Mgz

# Install dependencies
$ npm install

# Run the app
$ npm start
```

> **Note**
> If you're using Linux Bash for Windows, [see this guide](https://www.howtogeek.com/261575/how-to-run-graphical-linux-desktop-applications-from-windows-10s-bash-shell/) or use `node` from the command prompt.
